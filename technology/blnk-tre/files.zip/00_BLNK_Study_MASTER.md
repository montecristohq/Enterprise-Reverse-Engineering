# Blnk

**A Technology Reverse-Engineering Study — with a Build-Extraction Objective**

Six of seven volumes · Domain model and invariants · Architecture · Runtime behaviour · Implementation · Guarantees · Operations and rebuildability

Subject: the open-source double-entry financial ledger by Blnk Finance
Repository: `github.com/blnkfinance/blnk` · Apache-2.0
Research cut-off: 11 August 2026
First subject in the TREF programme

---

## ⚠ INTERIM BUILD — the gap check fails on one slot

**This study was commissioned in the EXTENDED 7 configuration. Volume VII — Security & Threat Model — has not been executed, and the reconstruction stage has not been written.**

The TREF reconstruction prompt requires a gap check before synthesis, on the principle that *synthesis across a hole produces a document that looks complete and is not, and the hole will be invisible to every subsequent reader.* This front matter is that declaration.

| | Volume | Status |
|---|---|---|
| **I** | Purpose, Domain & Conceptual Model | ✓ Complete |
| **II** | Architecture & Component Anatomy | ✓ Complete |
| **III** | Data, State, Control & Execution Flows | ✓ Complete — **partially superseded by IV, see the notice at its head** |
| **IV** | Implementation & Infrastructure Anatomy | ✓ Complete |
| **V** | Correctness, Performance, Scale & Reliability | ✓ Complete |
| **VI** | Operations, Tradeoffs, Ecosystem & Rebuildability | ✓ Complete |
| **VII** | **Security & Threat Model** | **✗ NOT EXECUTED** |
| **00** | **Reconstruction** | **✗ NOT WRITTEN** |

**What the missing volume would have established**, and what the reader therefore does not yet know: which of the guarantees ranked in Volume V can be broken *deliberately* rather than merely failing under load; where authorisation is enforced and what bypasses it; who can decrypt the data, including operators and backup holders; where sensitive data ends up that the design did not intend; the pattern formed by Blnk's disclosed vulnerabilities and what it says about the architecture; whether the project has a functioning security-response process; and which controls a new implementation cannot defer.

**For a ledger holding cooperative members' savings, that is not an optional appendix.** Volume VI's central judgement — fork Blnk, take its mechanisms, fix its correctness defaults — should be treated as provisional until Volume VII has tested the adversarial case.

---

## What this document is

A forensic technical reverse-engineering study of **Blnk**, an open-source double-entry financial ledger written in Go, backed by PostgreSQL and Redis, published under Apache-2.0 by Blnk Finance LLC.

**It is a build extraction, not a neutral teardown.** The reader is a founder building a proprietary core-banking platform for cooperative societies in Nigeria, intended to be permanently founder-owned on a vendor model, supporting member savings, contributions, loans and eventually remittance. Blnk was selected because it is the closest existing open-source analogue to the ledger layer of that platform — and because it is Nigerian in origin, which makes its design assumptions unusually relevant.

Every volume therefore carries **ADOPT / ADAPT / REJECT** verdicts, and Volume VI reaches a judgement on whether to adopt, fork, rebuild or look elsewhere.

| | Volume | The question it owns |
|---|---|---|
| **I** | Purpose, Domain & Conceptual Model | Why does this exist, what problem does it hold, and what does it promise never to violate? |
| **II** | Architecture & Component Anatomy | What are the parts, where do the boundaries fall, and what talks to what? |
| **III** | Data, State, Control & Execution Flows | What actually happens at runtime, and what happens when it goes wrong? |
| **IV** | Implementation & Infrastructure Anatomy | What is it actually made of, and what was bought rather than built? |
| **V** | Correctness, Performance, Scale & Reliability | What does it genuinely guarantee, and under what conditions do the guarantees hold? |
| **VI** | Operations, Tradeoffs, Ecosystem & Rebuildability | What does it cost to run, what was traded away, and could it be rebuilt? |
| **A** | Glossary | Ledger, Go, PostgreSQL and Redis vocabulary |
| **B** | Canonical Facts Register | The governing value for every material claim |
| **C** | The Invariant Chain | Twelve invariants tracked across four volumes |
| **D** | Source Register | What the study rests on, and the retrieval problem |
| **E** | Reconciliation | Where the volumes disagreed, and which governs |

**Recommended first pass.** Volume VI, sections 15–17 (rebuildability, preserve-versus-redesign, and the central judgement) → Volume V, section 1 (the guarantee ledger, ranked) → Volume IV, section 4 (the atomicity answer) → Appendix C (the invariant chain). The remaining material is reference-depth.

---

## Conventions governing the whole study

### §0 — Subject header

```text
Technology:              Blnk — open-source double-entry financial ledger
Technology type:         LEDGER
Primary repository:      github.com/blnkfinance/blnk
Client SDK:              github.com/blnkfinance/blnk-go (client interface only)
Version / release:       v0.15.2 (31 July 2026) — the governing pin
                         Volumes I and II were researched against v0.15.0 (22 June 2026)
Source openness:         OPEN SOURCE — Apache-2.0 ("Blnk Core"); open-core, Blnk Cloud commercial
Deployment model:        BOTH — self-hosted or managed Blnk Cloud
Research date:           11 August 2026
Study objective:         BUILD EXTRACTION
Configuration:           EXTENDED 7 — Volume VII commissioned, NOT EXECUTED
```

**On the version pin.** The study opened against v0.15.0 and Volumes IV, V and VI read v0.15.2 directly. **v0.15.2 governs.** Where a finding derives from v0.15.0 or earlier, the volume states the release. Behaviour is not silently mixed across releases.

### Evidence classification

| Label | Meaning |
|---|---|
| **CONFIRMED IMPLEMENTATION** | Verified in source, schema or specification — the file, function or clause is named |
| **DOCUMENTED BEHAVIOR** | Stated in official documentation but not verified in source |
| **MAINTAINER CLAIM** | Asserted by the project — a blog post, README, talk. **Not evidence of implementation** |
| **MEASURED RESULT** | A benchmark with methodology and conditions stated. Without conditions it is a MAINTAINER CLAIM |
| **SOURCE-CODE INFERENCE** | Reasoned from reading code, with the reasoning shown |
| **ANALYTICAL INFERENCE** | Reasoned from multiple known facts, with the reasoning shown |
| **HYPOTHESIS** | Plausible, requiring further evidence |
| **UNKNOWN** | The evidence is insufficient — flagged, never papered over |

**Three rules on use.** An inference is never silently promoted to a confirmation. Where documentation and source diverge, **the divergence is itself a finding** — and this study found several. And **every performance, scale and reliability claim the project makes about itself is a MAINTAINER CLAIM** until a MEASURED RESULT supersedes it; Blnk's "up to about 5×" throughput figure states no hardware, dataset, concurrency level or measured metric, and does not clear that bar.

### The evidence ceiling, and the retrieval problem

**This study's most instructive methodological finding is that an Apache-2.0 repository proved substantially unreadable by automated means for four volumes.**

GitHub's tree, blob and raw endpoints blocked retrieval; jsDelivr and the Go module proxy did not work. Volumes II and III were forced to work from documentation and, in Volume III's case, from a two-year-old public fork. **Volume IV broke it**: `pkg.go.dev` at the current module returns the complete exported API with source paths and line numbers, *and surfaces GitHub blob URLs at a version tag which can then be fetched.*

The consequence is recorded honestly throughout: **the PostgreSQL DDL was never read.** After four attempts across four volumes, Volume V declared the money column type **permanently UNKNOWN** for this study. Appendix E note 2 states the consequence.

### Never invent implementation

Where something could not be established, the study writes UNKNOWN, presents the plausible alternatives and names which the evidence favours. **A volume that quietly fills gaps with plausible-sounding architecture is worse than useless, because it is indistinguishable from one that did not.**

### The build-extraction verdicts

| Verdict | Meaning |
|---|---|
| **ADOPT** | Works on its own logic; carry it across substantially unchanged |
| **ADAPT** | The design intent transfers but the implementation must change — stated precisely |
| **REJECT** | Depends on scale, infrastructure, licensing or operational capacity the builder does not have |

Each carries the **environment question**: *did this work because of the mechanism itself, or because of the environment around it — the team, the scale, the deployment, the ecosystem?* Strip the environment out, then judge. **A REJECT is as valuable as an ADOPT**, and must carry its constructive half.

### Depth follows the subject

Sections are not of equal length. A section ends when its questions are answered.

---

## Contents

<!--TOC-->

---

<!--BODY-->

---

# APPENDIX A — GLOSSARY

## A.1 Ledger and accounting

| Term | Meaning |
|---|---|
| **Double-entry** | Every movement of value debits one account and credits another by the same amount. Blnk implements the *reciprocal transfer* core but renames debit and credit to **source** and **destination**, and does not expose the classical five-account-type normality model |
| **Ledger** (`ldg_`) | In Blnk, a grouping or namespace for balances — closer to a partition than the classical "book of final entry." A default **General Ledger** holds internal `@` balances |
| **Balance** (`bln_`) | ⚠ **Major redefinition.** A *stored, mutable, versioned* object with six money fields, not a value derived on demand. Textbook balance = credits − debits computed when asked; Blnk's is a cached running total that *can* be reconstructed |
| **Transaction** (`txn_`) | ⚠ **Redefinition.** A single source→destination transfer, not a balanced set of journal lines. Splits fan out into child transactions linked by `parent_transaction` |
| **Internal balance** (`@Name`) | An operator-owned balance representing the outside world, equity, revenue or fees. Auto-created in the General Ledger; typically runs negative under overdraft. **Blnk's substitute for a chart-of-accounts normality model** |
| **Reference** | A caller-supplied unique string; the idempotency key. Queued transactions receive a **`_q` suffix** on the stored record |
| **Precision** | ⚠ **Redefinition.** Not "number of decimal places" but the integer multiplier mapping display units to minor units. **Caller-supplied per transaction, not canonical per asset** |
| **`precise_amount`** | The authoritative amount, in smallest indivisible units, as Go `*big.Int` |
| **Inflight** | A held or pending transaction — Blnk's two-phase authorise-then-settle primitive. Commits, voids, expires, or partially commits |
| **Lineage** | Fund-source tracking: which credits funded a later debit, allocated FIFO, LIFO or proportionally |
| **Reconciliation** | Matching external records to internal transactions via rules and strategies |

## A.2 Runtime and infrastructure

| Term | Meaning |
|---|---|
| **`asynq`** | `github.com/hibiken/asynq` — the Redis-backed task queue. **Redis is therefore on the correctness path, not a cache** |
| **`redlock` MultiLocker** | Blnk's bespoke distributed lock over **both** balance IDs, deduplicated when source equals destination and **lexicographically sorted** to prevent deadlock |
| **Optimistic locking** | The `version` field on a balance; a write succeeds only if the version is unchanged since read |
| **`RecordTransactionWithBalancesAndOutbox`** | **The load-bearing correctness mechanism.** One composite datasource call persisting balances, the transaction row and the lineage outbox atomically |
| **Outbox** | A durable row written inside the same database transaction as the effect it describes, drained later by a worker. Blnk uses one for **lineage** but **not for webhooks** |
| **Coalescing** | Merging queued transactions sharing source, destination and currency into one batched commit — the hot-balance remedy |
| **Hot lane** | A routing mechanism isolating contended balance pairs from the general queue |
| **`QUEUE_BACKPRESSURE`** | HTTP 503 returned when Redis memory or pending-task count exceeds limits. Default-on since v0.15.2 |
| **Hash chain** | An optional global chain linking transactions via `ComputeChainHash`, sealed in batches by `ChainProcessor` and verified by `blnk verify-chain`. **Off by default** |
| **Balance reconstruction** | Recomputing a balance from its transaction history. Records a `difference` in metadata. **Does not alert** |

---

# APPENDIX B — CANONICAL FACTS REGISTER

**Where any volume disagrees with this table, this table governs.** Compiled 11 August 2026.

## B.1 The subject

| Item | Value | Evidence |
|---|---|---|
| Licence | **Apache-2.0** (Blnk Core) | CONFIRMED |
| Governing version | **v0.15.2** (31 July 2026) | CONFIRMED |
| Repository scale | ~604 commits · ~54 releases · 461 stars · 124 forks | CONFIRMED |
| Language | Go; one binary, three roles (`start`, `workers`, `migrate up`) | CONFIRMED |
| Required infrastructure | PostgreSQL (source of truth) + Redis (queue and locks) | CONFIRMED |
| Optional infrastructure | Typesense (search) · Jaeger/Prometheus (observability) | CONFIRMED |
| Vendor | Blnk Finance LLC, Delaware; founder Jerry Enebeli (Lagos) | CONFIRMED |
| Funding stage | Pre-seed; headcount band 1–10 (~2 per PitchBook); Microtraction investor | THIRD-PARTY |
| **Bus factor** | **≈ 1** — founder authors the majority of core PRs and cuts every release | ANALYTICAL INFERENCE |

**Disambiguation.** This is *not* the Egyptian BNPL lender "Blnk," nor Blink Charging (Nasdaq: BLNK), nor Blink home cameras. Three unrelated entities share the name.

## B.2 The money model

| Item | Value | Evidence |
|---|---|---|
| Go type for amounts | **`*big.Int`** end-to-end | CONFIRMED |
| Storage form | Integer minor units | DOCUMENTED |
| **PostgreSQL column type** | **PERMANENTLY UNKNOWN** — NUMERIC favoured, never confirmed | **UNKNOWN** |
| Consequence if NUMERIC | Effectively unbounded range | — |
| Consequence if BIGINT | Silent boundary at **±(2⁶³−1) ≈ ±9.22×10¹⁸ minor units** | ANALYTICAL INFERENCE |
| Float exposure | Gone from v0.15.x ingress when `precise_amount` is supplied; the convenience `amount` × `precision` path remains lossy | CONFIRMED |
| Precision model | **Caller-supplied per transaction**, not canonical per asset | DOCUMENTED |

## B.3 The correctness mechanisms

| Mechanism | Status | Evidence |
|---|---|---|
| Atomic composite write | `RecordTransactionWithBalancesAndOutbox` — "persisted atomically" | CONFIRMED (envelope inferred) |
| Idempotency | Unique index `idx_transactions_reference_unique` (v0.13.2); PG error `23505` via `IsDuplicateReferenceError` | CONFIRMED |
| Lock | `redlock.NewMultiLocker` over both balance IDs, sorted and deduplicated | CONFIRMED |
| Lock TTL default | **1800 seconds** — a live risk; expiry mid-operation removes serialisation | DOCUMENTED |
| Lock wait default | 3 seconds | DOCUMENTED |
| Optimistic locking | `version` field on balance | CONFIRMED |
| Hash chain | Present, batched, `chain_state` locked `FOR UPDATE`. **Off by default** | CONFIRMED |
| Lineage outbox | On the atomic write path; drained `FOR UPDATE SKIP LOCKED` | CONFIRMED |
| **Webhook outbox** | **None** — detached goroutine, at-most-once | CONFIRMED |
| Isolation level | **UNKNOWN** — likely READ COMMITTED, compensated by the Redis lock | UNKNOWN |
| Immutability trigger | Asserted by docs; **definition never read** | UNKNOWN |

## B.4 Configuration defaults

| Setting | Default |
|---|---|
| Queues | 20 |
| Max workers | 10 |
| Max retries | 3 |
| Retry delay | 5 seconds |
| **Lock duration** | **1800 seconds** |
| Lock wait | 3 seconds |
| Batch size | 100,000 |
| Max queue size | 1,000 |
| Coalescing batch max | 10,000 |
| Hash chain | **Disabled** |
| Backpressure | Enabled (v0.15.2+) |

## B.5 Breaking releases

| Release | Date | Break | Operator action |
|---|---|---|---|
| v0.11.0 | 27 Aug 2025 | Typesense/search behaviour | Reindex |
| v0.12.0 | 8 Dec 2025 | API keys hashed at rest | **Re-key every integration** |
| v0.13.2 | 12 Feb 2026 | Unique reference index | **De-duplicate first or the upgrade fails** |
| v0.15.0 | 23 Jun 2026 | Structured errors; **`rate`, `currency_multiplier`, `modification_ref` removed** | Rewrite any FX-dependent client code |

## B.6 Cost, sized for the reader

*A Nigerian cooperative group, 5,000–50,000 members, monthly contribution cycles, ~150k–300k transactions per month at the high end.*

| Line | Monthly |
|---|---|
| Compute (API + worker) | $40–$120 |
| Managed PostgreSQL | $60–$250 |
| Managed Redis | $15–$60 |
| Object storage (backups) | $5–$20 |
| Optional search and observability | $0–$60 |
| Bandwidth | $5–$20 |
| Licensing | **$0** |
| **Infrastructure subtotal** | **$150–$600** |
| **Operator labour** | **0.3–0.5 FTE — the dominant line** |
| One-time correctness-layer build | 4–8 engineer-weeks |
| Per-transaction infrastructure | ~$0.001–$0.003 |

---

# APPENDIX C — THE INVARIANT CHAIN

**The study's spine.** Volume I catalogued twelve invariants and their *claimed* enforcement points; Volume II located each in a component; Volume III verified each at runtime and classified it four ways; Volume V specified each as an assertable condition and ranked the resulting guarantees.

| # | Invariant | Where enforced | Classification | Governing evidence |
|---|---|---|---|---|
| **1** | **Conservation** — destination credit equals source debit | One `precise_amount` drives both legs via `model.UpdateBalances`; hardened by the v0.15.0 removal of `rate` | **Structural** | CONFIRMED |
| **2** | Balances change only through transactions | No public API mutates a balance directly; `CreateBalance` starts at zero | By check | CONFIRMED |
| **3** | Balance derivability | Reconstruction from history, on demand only | By check | DOCUMENTED |
| **4** | **Idempotency** | Unique index `idx_transactions_reference_unique` + PG `23505` | **Structural** (pre-check is optimisation) | CONFIRMED |
| **5** | Immutability of posted transactions | New `parent_transaction`-linked rows; DB protections asserted | Structural *if the trigger exists* — **definition unread** | DOCUMENTED |
| **6** | Valid state transitions | Guards in the inflight fetch-and-validate functions | By check | CONFIRMED |
| **7** | **Precision integrity** | `*big.Int` in Go; integer minor units in storage | **Structural in Go**; storage range **UNKNOWN** | CONFIRMED / UNKNOWN |
| **8** | Sufficient funds unless overdraft | Balance check including inflight since v0.11.0 | By check | DOCUMENTED |
| **9** | Concurrency safety | `redlock` MultiLocker + optimistic `version` | By check — **and the lock TTL can expire** | CONFIRMED |
| **10** | Zero and malformed rejected | Dropped before persistence | By check | CONFIRMED |
| **11** | Tamper-evidence | `HashTxn` per row; global chain via `ChainProcessor` | **By convention — off by default** | CONFIRMED |
| **12** | Authorisation and tenancy | Scoped, hashed, owner-bound API keys | Authz by check; **tenancy NOT ENFORCED — no component owns it** | CONFIRMED |

**The chain's verdict.** Four invariants are genuine guarantees — conservation, idempotency, precision-in-Go, and immutability if the trigger is real. The rest are code paths that hold while nothing unusual happens. **Two are not enforced at all in any meaningful sense: tamper-evidence, because it ships disabled, and tenancy, because nothing owns it.**

---

# APPENDIX D — SOURCE REGISTER

## D.1 What the study rests on

**Primary source.** The `blnkfinance/blnk` repository at tag v0.15.2 — `transaction_execution.go` and `transaction.go` read in full; the exported API of every package via `pkg.go.dev`, with file paths and line numbers; `docker-compose.yaml`; `metadata_test.go`. Volume III additionally read `transaction.go` from the public Apache-2.0 fork `northstar-pay/nucleus` at commit `1cb559337258` (August 2024) — **clearly labelled throughout, and superseded by Volume IV wherever it conflicts.**

**Official documentation.** `docs.blnkfinance.com` — the changelog (the single most useful document in the corpus, and an honest technical-debt register), the configuration reference, the transaction and balance guides, the hot-balances guide, the deployment and backup pages, and the API error-code reference.

**Maintainer writing, treated as MAINTAINER CLAIM.** The Blnk Finance blog, particularly the hot-balances, idempotency and v0.10.1 posts; the README; conference and community material.

**Company and governance evidence.** Crunchbase and PitchBook for funding stage and headcount; GitHub for commit concentration, release cadence, contributor count and repository traction.

**Comparative material.** TigerBeetle documentation and an independent third-party benchmark; Formance Ledger documentation; the Midaz repository and README, including its Elastic License 2.0 terms.

## D.2 The retrieval problem — a methodological finding

**An Apache-2.0 repository proved substantially unreadable by automated means for four consecutive volumes**, and the study records this as a finding rather than an excuse.

What failed: GitHub tree, blob and raw endpoints (robots-blocked); `jsDelivr`; the Go module proxy; bare `raw.githubusercontent.com`; code-search indexes.

What worked, from Volume IV onward: **`pkg.go.dev` at the current module**, which returns the complete exported API with source paths and line numbers **and surfaces GitHub blob URLs at a version tag that can then be fetched directly.**

**The cost of the delay.** Volume II could not confirm the schema; Volume III was forced onto a two-year-old fork and produced three findings that Volume IV had to supersede; and the DDL was never read at all. **Any future TREF study should attempt the `pkg.go.dev` route first.**

## D.3 What was never read

The `sql/` directory, embedded in the binary as `SQLFiles embed.FS`, containing the schema DDL. Also unread: the body of `database/transaction.go` (so the `BeginTx` envelope inside the composite write is inferred, not confirmed); the body of `internal/redlock` (so the lock's Redis commands and retry interval are inferred from the pattern); and the test files covering concurrency, partial failure and the immutability trigger — **so the test status of the correctness-critical paths is UNKNOWN rather than confirmed-absent.**

---

# APPENDIX E — RECONCILIATION

Six volumes researched independently against a repository that was intermittently unreadable, spanning two release pins and, in one case, a two-year-old fork. **Three genuine corrections were applied at source; two version differences are recorded as such; and one question is declared permanently unresolved.**

## E.1 Corrections applied at source

**Note 1 — the lock package name. CORRECTED in Volume II.** Volumes II and III identified the distributed lock as `internal/lock`. **Volume IV read the current source and established the package is `internal/redlock`**, providing a `MultiLocker`. Volume IV governs; Volume II is corrected in place at four occurrences, with a visible inline note at the first.

**Note 2 — the money column type. SUPERSEDED in Volumes I and II.** Both volumes inferred **NUMERIC** and labelled it inference. Volume V, after a fourth failed retrieval attempt, **declared the type permanently UNKNOWN for this study.** Volume V governs; both earlier volumes now carry an inline note at the point of inference.

*The consequence, stated plainly:* the representable balance range cannot be confirmed. If NUMERIC, it is effectively unbounded. If BIGINT, there is a silent boundary at **±(2⁶³−1) ≈ ±9.22×10¹⁸ minor units** — comfortable for a naira or dollar cooperative at `precision = 100`, and dangerous at `precision = 10¹⁸`. **The reader must read the DDL in his own deployment before trusting large balances.** This is the first item in Volume VI's recommendations for that reason.

**Note 3 — Volume III's runtime findings. SUPERSEDED by Volume IV, with a banner at the head of Volume III.** Volume III was researched against the 2024 fork and reported: balances persisted *before* the transaction row as two separate calls; a lossy `int64(Amount × Precision)` float multiply at ingress; and a lock keyed on the source balance alone.

**Volume IV read v0.15.2 directly and found all three superseded** — a single atomic composite write, `*big.Int` accepted directly, and a MultiLocker over both balances. Volume IV governs.

**This is the method working, not failing.** Volume III explicitly anticipated it: *"If v0.15.x already wraps the two writes atomically, Findings 2–3 and the worst partial-success rows soften — verify against the current `transaction.go` before building."* Volume IV verified, and they did.

## E.2 Version differences — not conflicts

**Note 4 — the release pin.** Volumes I and II were researched against **v0.15.0** (22 June 2026); Volumes IV, V and VI read **v0.15.2** (31 July 2026). **v0.15.2 governs the assembled study.** The difference is material in three places: the queued inflight commit/void default, the lock-duration overflow fix, and queue and Typesense memory backpressure. Where a volume describes v0.15.0 behaviour it says so.

**Note 5 — the fork.** Volume III's source reading comes from `northstar-pay/nucleus` at August 2024, roughly two years before the pinned release. **This is a vintage difference, not an error**, and the banner at the head of Volume III states which findings survive and which do not.

## E.3 Unknowns carried forward

The study could not resolve, and does not pretend to have resolved:

- **The PostgreSQL column type for money**, and any CHECK constraints on sign, magnitude or precision. Permanently UNKNOWN after four attempts.
- **The exact definition of the unique reference index** — whether partial, whether created CONCURRENTLY.
- **The immutability trigger** — its name, its protected columns, and its behaviour on violation. Asserted by documentation, never read.
- **The transaction isolation level** used inside the composite write. Likely READ COMMITTED; the Redis lock is doing the serialisation work either way.
- **The `BeginTx` envelope** inside `RecordTransactionWithBalancesAndOutbox` — inferred from the single call site, the "persisted atomically" comments and the `InsertLineageOutboxInTx(tx *sql.Tx)` signature, but not read.
- **The `internal/redlock` implementation body** — the Redis commands, retry interval and failure sentinel.
- **Test coverage of the correctness-critical paths** — concurrent duplicate references, MultiLocker ordering, partial-failure rollback, and the trigger. UNKNOWN, not confirmed-absent.
- **Third-party production evidence at scale.** Vendor testimonials assert it; no independent quantified case study was found.
- **Blnk Finance's runway, next raise, and the exact top-contributor commit share.**
- **Everything Volume VII would have established.** See the gap declaration at the head of this document.

## E.4 A note on what the reconciliation demonstrates

**The most valuable thing this study produced is not a finding about Blnk but a demonstration that the method catches its own errors.** Volume III wrote down the condition under which its own conclusions would collapse; Volume IV tested it; the conclusions collapsed; and the record now says so in the body of Volume III where a reader meets it, rather than in a footnote.

A study that had smoothed that over would have told the reader that Blnk carries a durable partial-write hazard. **It does not, and the difference between those two answers is the difference between forking this ledger and abandoning it.**
