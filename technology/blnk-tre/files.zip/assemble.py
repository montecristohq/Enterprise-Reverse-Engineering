#!/usr/bin/env python3
"""Assemble the Blnk TREF study. Gap-checks against the declared configuration."""
import re, pathlib, unicodedata, sys

BASE=pathlib.Path(__file__).parent; ST=BASE/"stages"
TITLES={1:"VOLUME I — Purpose, Domain & Conceptual Model",
        2:"VOLUME II — Architecture & Component Anatomy",
        3:"VOLUME III — Data, State, Control & Execution Flows",
        4:"VOLUME IV — Implementation & Infrastructure Anatomy",
        5:"VOLUME V — Correctness, Performance, Scale & Reliability",
        6:"VOLUME VI — Operations, Tradeoffs, Ecosystem & Rebuildability"}
DECLARED={7:"VOLUME VII — Security & Threat Model"}   # commissioned, not executed

missing=[n for n in TITLES if not (ST/f"v{n:02d}.md").exists()]
if missing: sys.exit(f"ABORT — core volume(s) missing: {sorted(missing)}")
absent=[n for n in DECLARED if not (ST/f"v{n:02d}.md").exists()]
if absent:
    print("GAP CHECK: " + ", ".join(f"{DECLARED[n]} NOT EXECUTED" for n in absent))
    print("           → building INTERIM; gap declared in front matter.\n")

def normalise(text,n):
    lines=text.splitlines(); i=0
    while i<len(lines) and not lines[i].strip(): i+=1
    if i<len(lines) and lines[i].startswith("#") and not lines[i].startswith("###"):
        i+=1
        while i<len(lines) and (not lines[i].strip() or lines[i].startswith("```")):
            if lines[i].startswith("```"):
                i+=1
                while i<len(lines) and not lines[i].startswith("```"): i+=1
                i+=1
            else: i+=1
    return "\n".join([f"# {TITLES[n]}",""]+lines[i:])

def slug(s):
    s=re.sub(r"<[^>]+>","",s); s=re.sub(r"[*_`\[\]()]","",s).strip().lower()
    s="".join(c for c in unicodedata.normalize("NFKD",s) if not unicodedata.combining(c) or c in "—–")
    s=re.sub(r"[^\w\s-]","",s); return re.sub(r"\s+","-",s).strip("-")

def toc(body):
    seen={}; out=[]
    for m in re.finditer(r"^(#{1,3}) (.+)$",body,re.M):
        lvl,txt=len(m.group(1)),m.group(2).strip()
        if txt.lower().startswith(("contents","table of contents")): continue
        a=slug(txt); seen[a]=seen.get(a,0)+1
        if seen[a]>1: a=f"{a}-{seen[a]-1}"
        out.append("  "*(lvl-1)+f"- [{txt}](#{a})")
    return "\n".join(out)

body="\n\n---\n\n".join(normalise((ST/f"v{n:02d}.md").read_text(encoding="utf-8"),n).strip()
                        for n in sorted(TITLES))
doc=(BASE/"00_BLNK_Study_MASTER.md").read_text(encoding="utf-8")
doc=doc.replace("<!--TOC-->",toc(body)).replace("<!--BODY-->",body.strip()).rstrip()+"\n"
(BASE/"BLNK_TREF_Study_INTERIM.md").write_text(doc,encoding="utf-8")

L=[l for l in doc.splitlines() if l.strip().startswith("|")]
S=[l for l in L if re.match(r"^\|[\s:|-]+\|$",l.strip())]
print(f"words   {len(doc.split()):,}")
print(f"tables  {len(S)}  data rows {len(L)-len(S)}")
print(f"h1 {len(re.findall(r'^# ',doc,re.M))}  h2 {len(re.findall(r'^## ',doc,re.M))}  h3 {len(re.findall(r'^### ',doc,re.M))}")
for lab in ["CONFIRMED IMPLEMENTATION","DOCUMENTED BEHAVIOR","MAINTAINER CLAIM","MEASURED RESULT","SOURCE-CODE INFERENCE","ANALYTICAL INFERENCE","HYPOTHESIS","UNKNOWN"]:
    print(f"  {lab:26} {doc.count(lab)}")
for v in ("ADOPT","ADAPT","REJECT"): print(f"  {v}: {len(re.findall(rf'\b{v}\b',doc))}")
